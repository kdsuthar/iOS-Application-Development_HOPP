//
//  AIUtilsManager.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit


func setUserDefaultsValue(_ value : Any, _ key : String)
{
    UserDefaults.standard.setValue(value, forKey: key)
    UserDefaults.standard.synchronize()
}

func removeUserDefaultsValue(_ key : String)
{
    UserDefaults.standard.removeObject(forKey: key)
    UserDefaults.standard.synchronize()
}

func getUserDefaultsValue(_ key : String) -> Any?
{
    return UserDefaults.standard.value(forKey: key)
}


//MARK: - SCREEN SIZE
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height
let SCREEN_WIDTH = UIScreen.main.bounds.size.width


func GET_PROPORTIONAL_WIDTH(width: CGFloat) -> CGFloat
{
    return CGFloat(Int((SCREEN_WIDTH * width)/375))
}

func GET_PROPORTIONAL_HEIGHT(height: CGFloat) -> CGFloat
{
    return CGFloat(Int((SCREEN_HEIGHT * height)/667))
}

func GET_DYNAMIC_PROPORTIONAL_WIDTH(width: CGFloat,viewHeight : CGFloat) -> CGFloat
{
    return CGFloat(Int((SCREEN_WIDTH * width)/viewHeight))
}

func GET_DYNAMIC_PROPORTIONAL_HEIGHT(height: CGFloat,viewHeight : CGFloat) -> CGFloat
{
    return CGFloat(Int((SCREEN_HEIGHT * height)/viewHeight))
}


func noDataView(frame : CGRect = UIScreen.main.bounds) -> UIView{
    let viewNoData = UIView()
    viewNoData.frame = frame
    viewNoData.backgroundColor = UIColor.white
    let noDataLabel = BaseLabelRegular()
    noDataLabel.frame = viewNoData.frame
    noDataLabel.text = "No Properties Found"
    noDataLabel.textColor = UIColor.black
   // noDataLabel.font = UIFont.APP_FONT_Regular(fontsize: 16)
    noDataLabel.textAlignment = .center
    viewNoData.addSubview(noDataLabel)
    
    return viewNoData
}


struct DeviceType {
    static let iPhone: Bool = UIDevice.current.userInterfaceIdiom == .phone
    static let iPad: Bool = UIDevice.current.userInterfaceIdiom == .pad
    
    static let iPhone_4_OR_4S: Bool = (SCREEN_HEIGHT == 480)
    static let iPhone_5_OR_5S: Bool = (SCREEN_HEIGHT == 568)
    static let iPhone_6_OR_6S: Bool = (SCREEN_HEIGHT == 667)
    static let iPhone_6P_OR_6SP: Bool = (SCREEN_HEIGHT == 736)
    static let iPhone_X_OR_XS: Bool = (SCREEN_HEIGHT == 812)
    static let iPhone_XR_OR_XS_MAX: Bool = (SCREEN_HEIGHT == 896)
}

//MARK:- getPropostionalFontSize
func getPropostionalFontSize(_ size:CGFloat) -> CGFloat
{
    var sizeToCheckAgainst = size
    if(DeviceType.iPad)
    {
        sizeToCheckAgainst = size * (SCREEN_HEIGHT/736)
    }
    else
    {
        if(DeviceType.iPhone_6P_OR_6SP) {
            sizeToCheckAgainst += 1
        }
        else if(DeviceType.iPhone_6_OR_6S) {
            sizeToCheckAgainst -= 0
        }
        else if(DeviceType.iPhone_5_OR_5S) {
            sizeToCheckAgainst -= 2
        }
        else if(DeviceType.iPhone_4_OR_4S) {
            sizeToCheckAgainst -= 3
        }else if(DeviceType.iPhone_X_OR_XS) {
            sizeToCheckAgainst += 1
        }else if(DeviceType.iPhone_XR_OR_XS_MAX) {
            sizeToCheckAgainst += 1
        }
        
    }
    
    return sizeToCheckAgainst
}


func delay(_ delay:Double, closure:@escaping ()->()) {
    let when = DispatchTime.now() + delay
    DispatchQueue.main.asyncAfter(deadline: when, execute: closure)
}


// MARK:-  iPhone Check
//Check isIPhone Device
func IS_IPHONE_DEVICE() -> Bool
{
    let deviceType = UIDevice.current.userInterfaceIdiom == .phone
    return deviceType
}

//Check IsIPad Device
func IS_IPAD_DEVICE() -> Bool
{
    let deviceType = UIDevice.current.userInterfaceIdiom == .pad
    return deviceType
}

//iPhone 4 OR 4S
func IS_IPHONE_4_OR_4S() -> Bool
{
    let SCREEN_HEIGHT_TO_CHECK_AGAINST:CGFloat = 480
    if(SCREEN_HEIGHT_TO_CHECK_AGAINST == SCREEN_HEIGHT)
    {
        return true
    }
    return false
}

//iPhone 5 OR OR 5C OR 5S
func IS_IPHONE_5_OR_5S() -> Bool
{
    let SCREEN_HEIGHT_TO_CHECK_AGAINST:CGFloat = 568
    if(SCREEN_HEIGHT_TO_CHECK_AGAINST == SCREEN_HEIGHT)
    {
        return true
    }
    return false
}

//iPhone 6 OR 6S
func IS_IPHONE_6_OR_6S() -> Bool
{
    let SCREEN_HEIGHT_TO_CHECK_AGAINST:CGFloat = 667
    if(SCREEN_HEIGHT_TO_CHECK_AGAINST == SCREEN_HEIGHT)
    {
        return true
    }
    return false
}

//iPhone 6Plus OR 6SPlus
func IS_IPHONE_6P_OR_6SP() -> Bool
{
    let SCREEN_HEIGHT_TO_CHECK_AGAINST:CGFloat = 736
    if(SCREEN_HEIGHT_TO_CHECK_AGAINST == SCREEN_HEIGHT)
    {
        return true
    }
    return false
}

//iPhone X
func IS_IPHONE_X() -> Bool
{
    let SCREEN_HEIGHT_TO_CHECK_AGAINST:CGFloat = 812
    if(SCREEN_HEIGHT_TO_CHECK_AGAINST == SCREEN_HEIGHT)
    {
        return true
    }
    return false
}

func IS_IPhone_XR_OR_XS_MAX() -> Bool
{
    let SCREEN_HEIGHT_TO_CHECK_AGAINST:CGFloat = 896
    if(SCREEN_HEIGHT_TO_CHECK_AGAINST == SCREEN_HEIGHT)
    {
        return true
    }
    return false
}
