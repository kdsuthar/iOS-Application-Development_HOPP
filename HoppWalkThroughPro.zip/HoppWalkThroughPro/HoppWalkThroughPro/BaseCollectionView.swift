//
//  BaseCollectionView.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit


class BaseCollectionView: UICollectionView
{
    
}
