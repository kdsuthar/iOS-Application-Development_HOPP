//
//  BaseButton.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit

class BaseButton: UIButton
{
    fileprivate var textColor: UIColor = UIColor.white
    fileprivate var backColor: UIColor? = nil
    fileprivate var needToUpdateOnHighlight: Bool = false
    var isPhonePadbutton: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    //    func adjustPhonePadbutton() {
    //        self.textColor = UIColor.appLightGrayColor
    //        self.textColor = UIColor.appDarkGrayColor
    //    }
    
    func adjustSelectedHighlightedStage() {
        self.textColor = self.titleColor(for: .normal)!
        self.backColor = self.backgroundColor!
        
        self.setTitleColor(self.textColor, for: .normal)
        self.needToUpdateOnHighlight = true
        if let backColor = self.backColor {
            self.setTitleColor(backColor, for: .selected)
            self.setTitleColor(backColor, for: .highlighted)
        }
    }
    
    override var isHighlighted: Bool {
        willSet {
            if self.needToUpdateOnHighlight {
                if newValue {
                    self.backgroundColor = self.textColor
                    //if let backColor = self.backColor, self.layer.borderWidth > 0.0 {
                    if let _ = self.backColor, self.layer.borderWidth > 0.0 {
                        self.layer.borderColor = UIColor.clear.cgColor //backColor.cgColor
                    }
                }
                else {
                    self.backgroundColor = self.backColor
                    if self.layer.borderWidth > 0.0 {
                        self.layer.borderColor = self.textColor.cgColor
                    }
                }
            }
            else if self.isPhonePadbutton {
                if newValue {
                    //  self.setTitleColor(UIColor.appDarkGrayColor, for: .normal)
                    if self.layer.borderWidth > 0.0 {
                        //      self.layer.borderColor = UIColor.appDarkGrayColor.cgColor
                    }
                }
                else {
                    //   self.setTitleColor(UIColor.appLightGrayColor, for: .normal)
                    if self.layer.borderWidth > 0.0 {
                        //      self.layer.borderColor = UIColor.appLightGrayColor.cgColor
                    }
                }
            }
            
            
        }
    }
    
    
    
    // func setUpThemeButton(withColor : UIColor? = Theme.current.whiteColor,background :UIColor? = Theme.current.buttonThemeDarkBackgroundColor){
    //   self.backgroundColor = background
    //   self.setTitleColor(withColor, for: .normal)
    //  self.setTitleColor(withColor, for: .selected)
    //  self.setTitleColor(withColor, for: .highlighted)
    //        self.titleLabel?.font = UIFont.APP_FONT_SemiBold(fontsize: 16.0)
    // }
    
    // func setUpClearButton(withColor : UIColor = Theme.current.textThemeDarkColor ){
    //     self.backgroundColor = Theme.current.clearColor
    //     self.setTitleColor(withColor, for: .normal)
    //    self.setTitleColor(withColor, for: .selected)
    //    self.setTitleColor(withColor, for: .highlighted)
    // }
    
    //  func setUpBorderedButton(withColor : UIColor = Theme.current.viewDarkBackgroundColor){
    //      self.backgroundColor = Theme.current.clearColor
    //      self.setTitleColor(withColor, for: .normal)
    //     self.setTitleColor(withColor, for: .selected)
    //     self.setTitleColor(withColor, for: .highlighted)
    //     self.addBorder(color:Theme.current.borderLightColor)
    // }
    
    //  func setUpWhiteButton(withColor : UIColor = Theme.current.textDarkColor){
    //    self.backgroundColor = Theme.current.whiteColor
    //   self.setTitleColor(withColor, for: .normal)
    //   self.setTitleColor(withColor, for: .selected)
    //   self.setTitleColor(withColor, for: .highlighted)
    
    //}
    
    
    //  func setUpButton(backgroundColor : UIColor , textColor : UIColor){
    //      self.backgroundColor = backgroundColor
    //      self.setTitleColor(textColor, for: .normal)
    //     self.setTitleColor(textColor, for: .selected)
    //     self.setTitleColor(textColor, for: .highlighted)
    
    //  }
    
    // func addThemeShadow(){
    //     self.applyShadowWithColor(color: Theme.current.shadowThemeDarkColor, opacity: 0.25, cornerRadius: (min(self.height, self.width))/2, shadowRadius: 10.0, edge: .Bottom, shadowSpace:8.0)
    //}
    
    //   func addDefaulthadow(){
    //       self.applyShadowWithColor(color: Theme.current.shadowLightColor, opacity: 0.2, cornerRadius: (min(self.height, self.width))/2, shadowRadius: 7.0, edge: .Bottom, shadowSpace:5.0)
    //   }
    
    //  func addShadowWith(color : UIColor = Theme.current.shadowLightColor){
    //      self.applyShadowWithColor(color: color, opacity: 0.25, cornerRadius: (min(self.height, self.width))/2, shadowRadius: 10.0, edge: .Bottom, shadowSpace:8.0)
    //   }
    
    //  func removeShadow(){
    //     self.applyShadowWithColor(color: Theme.current.clearColor, opacity: 0.0, cornerRadius: (min(self.height, self.width))/2, shadowRadius: 7.0, edge: .None, shadowSpace:5.0)
    // }
    
    //   func setUpWhiteTextButton(){
    //      self.backgroundColor = Theme.current.clearColor
    //      self.setTitleColor(Theme.current.whiteColor, for: .normal)
    //      self.setTitleColor(Theme.current.whiteColor, for: .selected)
    //      self.setTitleColor(Theme.current.whiteColor, for: .highlighted)
    
    //  }
    
    //  func clearColorBackgroundColor(){
    //       self.backgroundColor = Theme.current.clearColor
    //  }
    
    func setTitleWithColor(color : UIColor){
        
        self.setTitleColor(color, for: .normal)
        self.setTitleColor(color, for: .selected)
        self.setTitleColor(color, for: .highlighted)
        
    }
    
    func setRadioButtonWithTitle(title : String, and color:UIColor){
        
        //        self.setImage(UIImage.radioActive(), for: .selected)
        //        self.setImage(UIImage.radioInactive(), for: .normal)
        
        self.setTitle(title, for: .normal)
        self.setTitle(title, for: .selected)
        self.setTitle(title, for: .highlighted)
        
        self.setTitleColor(color, for: .normal)
        self.setTitleColor(color, for: .selected)
        self.setTitleColor(color, for: .highlighted)
        
    }
    
    func setTitleWithAttribute(title1 : String,title2 : String,color1 : UIColor,color2 : UIColor,font1: UIFont,font2: UIFont,iswithNewLine : Bool){
        var strFinal = ""
        if iswithNewLine {
            strFinal = "\(title1)\n\(title2)"
        }else{
            strFinal = "\(title1) \(title2)"
        }
        
        let attributeString = NSMutableAttributedString(string: strFinal)
        
        attributeString.addAttributes([NSAttributedString.Key.font: font1, NSAttributedString.Key.foregroundColor : color1], range: (strFinal as NSString).range(of: title1))
        attributeString.addAttributes([NSAttributedString.Key.font: font2, NSAttributedString.Key.foregroundColor : color2], range: (strFinal as NSString).range(of: title2))
        
        self.setAttributedTitle(attributeString, for: .normal)
        self.setAttributedTitle(attributeString, for: .selected)
        self.setAttributedTitle(attributeString, for: .highlighted)
        
        
        
        
    }
    
    func setButtonWithRightImage(){
        self.semanticContentAttribute = .forceRightToLeft
        self.contentEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 15)
        self.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.imageEdgeInsets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: -15)
    }
    
    func setTitleColor(_ titleColor:UIColor){
        self.setTitleColor(titleColor, for: .normal)
    }
    
    func setTitleWithText(_ title:String){
        self.setTitle(title, for: .normal)
        self.setTitle(title, for: .highlighted)
        self.setTitle(title, for: .selected)
    }
    
    func setTitleWithImage(_ image:UIImage , renderMode:UIImage.RenderingMode = .alwaysTemplate){
        self.setImage(image.withRenderingMode(renderMode), for: .normal)
        self.setImage(image.withRenderingMode(renderMode), for: .highlighted)
        self.setImage(image.withRenderingMode(renderMode), for: .selected)
        
    }
}

//class BaseButtonLight: BaseButton {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.titleLabel?.font = UIFont.APP_FONT_Light(fontsize: 14.0)
//    }
//}

class BaseButtonRegular: BaseButton {
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        //  self.titleLabel?.font = UIFont.APP_FONT_Regular(fontsize: 14.0)
    }
}


class BaseButtonRegularDays: BaseButton {
    
    override var isSelected: Bool {
        get {
            return super.isSelected
        }
        set {
            if newValue {
                //       backgroundColor = Theme.current.buttonThemeDarkBackgroundColor
                //       self.setTitleColor(Theme.current.whiteColor, for: .selected)
            }
            else {
                //       backgroundColor = Theme.current.buttonThemeMediumBackgroundColor
                //        self.setTitleColor(Theme.current.textDarkColor, for: .normal)
            }
            super.isSelected = newValue
        }
    }
    
    override var isEnabled: Bool{
        didSet{
            if isEnabled{
                self.alpha = 1.0
            }else{
                self.alpha = 0.5
            }
        }
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
      //   self.titleLabel?.font = UIFont.APP_FONT_Regular(fontsize: 14.0)
    }
}

class BaseButtonSemiBold: BaseButton {
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
       // self.titleLabel?.font = UIFont.APP_FONT_SemiBold(fontsize: 14.0)
    }
}



