//
//  ThemeOne.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit

class ThemeOne: ThemeProtocol
{
    var clearColor: UIColor = UIColor.clear
    var whiteColor: UIColor = UIColor.appWhite
    var blackColor: UIColor = UIColor.appBlack
    var devideColor: UIColor = UIColor.appDevideBlack
    var imageBorder: UIColor = UIColor.appImageBorderBlack
    
    
    //App Extra Color Backgroud Color
    var appRedGoogle : UIColor = UIColor.appRedGoogle
    var appBlueFacebook : UIColor = UIColor.appBlueFacebook
    var appRed : UIColor = UIColor.appRed
    var appOrange : UIColor = UIColor.appOrange
    var appGreen : UIColor = UIColor.appGreen
    
    
    //Rating Star Backgroud Color
    var ratingColor : UIColor = UIColor.appYello
    
    
    //view Theme Backgroud Color (Only for theme color change)
    var viewThemeDarkBackgroundColor: UIColor = UIColor.appThemeColorDark
    var viewThemeMediumBackgroundColor: UIColor = UIColor.appThemeColorMedium
    var viewThemeLightBackgroundColor: UIColor = UIColor.appThemeColorLight
    
    //view Default Backgroud Color
    var viewDarkBackgroundColor: UIColor = UIColor.appDarkGrayColor
    var viewMediumBackgroundColor: UIColor = UIColor.appMediumGrayColor
    var viewLightBackgroundColor: UIColor = UIColor.appLightGrayColor
    
    
    
    //Button Backgroud Color
    var buttonDarkBackgroundColor: UIColor = UIColor.appDarkGrayColor
    var buttonMediumBackgroundColor: UIColor = UIColor.appMediumGrayColor
    var buttonLightBackgroundColor: UIColor = UIColor.appThemeColorLight
    var buttonMoreLightBackgroundColor: UIColor = UIColor.appLightGrayColor
    
    //Button Backgroud Color
    var buttonThemeDarkBackgroundColor: UIColor = UIColor.appThemeColorDark
    var buttonThemeMediumBackgroundColor: UIColor = UIColor.appThemeColorMedium
    var buttonThemeLightBackgroundColor: UIColor = UIColor.appThemeColorLight
    var buttonThemeMoreLightBackgroundColor: UIColor = UIColor.appThemeColorMoreLight
    
    //Text Theme Color (Only for theme color change)
    var textThemeDarkColor: UIColor = UIColor.appThemeColorDark
    var textThemeMediumColor: UIColor = UIColor.appThemeColorMedium
    var textThemeLightColor: UIColor = UIColor.appThemeColorLight
    
    //Text Default Color
    var textDarkColor: UIColor = UIColor.appDarkGrayColor
    var textMediumColor: UIColor = UIColor.appMediumGrayColor
    var textLightColor: UIColor = UIColor.appLightGrayColor
    
    //Text Status Color
    var textRedColor: UIColor = UIColor.appRed
    var textGreenColor: UIColor = UIColor.appGreen
    var textOrangeColor: UIColor = UIColor.appOrange
    
    //Shadow Theme Color (Only for theme color change)
    var shadowThemeDarkColor: UIColor = UIColor.appThemeShadowColorDark
    var shadowThemeMediumColor: UIColor = UIColor.appThemeShadowColorDark
    var shadowThemeLightColor: UIColor = UIColor.appThemeShadowColorDark
    
    //Shadow Default Color
    var shadowDarkColor: UIColor = UIColor.appDarkGrayColor
    var shadowMediumColor: UIColor = UIColor.appMediumGrayColor
    var shadowLightColor: UIColor = UIColor.appLightGrayColor
    
    //Border Theme Color (Only for theme color change)
    var borderThemeDarkColor: UIColor = UIColor.appThemeColorDark
    var borderThemeMediumColor: UIColor = UIColor.appThemeColorMedium
    var borderThemeLightColor: UIColor = UIColor.appThemeColorLight
    
    //Border Default Color
    var borderDarkColor: UIColor = UIColor.appDarkGrayColor
    var borderMediumColor: UIColor = UIColor.appMediumGrayColor
    var borderLightColor: UIColor = UIColor.appLightGrayColor
    
    
    
    //    var darkThemeBackgroundColor: UIColor = UIColor.appThemeColorDark
    //    var mediumThemeBackgroundColor: UIColor = UIColor.appThemeColorMedium
    //    var lightThemeBackgroundColor: UIColor = UIColor.appThemeColorLight
    //
    //
    ////    var darkBackgroundColor: UIColor = UIColor.appThemeColorDark
    ////    var mediumBackgroundColor: UIColor = UIColor.appThemeColorMedium
    ////    var lightBackgroundColor: UIColor = UIColor.appThemeColorLight
    //
    //    var darkTextColor: UIColor = UIColor.appDarkGrayColor
    //    var mediumTextColor: UIColor = UIColor.appMediumGrayColor
    //    var lightTextColor: UIColor = UIColor.appLightGrayColor
    //
    //    var darkThemeTextColor: UIColor  = UIColor.appThemeColorDark
    //    var mediumThemeTextColor: UIColor  = UIColor.appThemeColorMedium
    //    var lightThemeTextColor: UIColor = UIColor.appThemeColorLight
    //
    //    var darkAccentColor: UIColor = UIColor.appDarkGrayColor
    //    var mediumAccentColor: UIColor = UIColor.appLightGrayColor
    //    var lightAccentColor: UIColor = UIColor.appWhite
    //
    //    var darkSelectedAccentColor: UIColor = UIColor.appThemeColorDark
    //    var mediumSelectedAccentColor: UIColor = UIColor.appThemeColorMedium
    //    var lightSelectedAccentColor: UIColor = UIColor.appThemeColorLight
    //
    //
    //    var layerColor: UIColor = UIColor.appThemeColorMedium.withAlphaComponent(0.33)
    //    var tintColor: UIColor = UIColor.appDarkGrayColor
    //
    //    var brandColor: UIColor = UIColor.appThemeColorDark
    //
    //
    //
    //    var darkShadowColor: UIColor = UIColor.appDarkGrayColor
    //    var mediumShadowColor: UIColor = UIColor.appMediumGrayColor
    //    var lightShadowColor: UIColor = UIColor.appLightGrayColor
    
    
}

//class FontOne: FontProtocol {
    
    
  // var Regular: String = R.font.segoeUI.fontName
    
  //  var Semibold: String = R.font.segoeUISemibold.fontName
    
    
//}
