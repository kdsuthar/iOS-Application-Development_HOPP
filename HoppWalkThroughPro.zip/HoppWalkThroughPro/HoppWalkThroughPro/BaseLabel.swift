//
//  BaseLabel.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit

class BaseLabel: UILabel {
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    override public var canBecomeFirstResponder: Bool {
        get {
            return true
        }
    }
    
    func longPressMenu() {
        isUserInteractionEnabled = true
        addGestureRecognizer(UILongPressGestureRecognizer(
            target: self,
            action: #selector(showMenu(sender:))
        ))
    }
    
    //    func canBecomeFirstResponder() -> Bool {
    //        return true
    //    }
    
    override func copy(_ sender: Any?) {
        UIPasteboard.general.string = text
        UIMenuController.shared.setMenuVisible(false, animated: true)
    }
    
    @objc func showMenu(sender: Any?) {
        becomeFirstResponder()
        let menu = UIMenuController.shared
        if !menu.isMenuVisible {
            menu.setTargetRect(bounds, in: self)
            menu.setMenuVisible(true, animated: true)
        }
    }
    
    
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return (action == #selector(copy(_:)))
    }
    
    
}

//class BaseLabelLight: BaseLabel {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.font = UIFont.APP_FONT_Light(fontsize: 14.0)
//    }
//
//
//
//}


class BaseLabelRegular: BaseLabel {
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        //self.font = UIFont.APP_FONT_Regular(fontsize: self.font!.pointSize)
    }
    
}

class BaseLabelSemiBold: BaseLabel {
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
       // self.font = UIFont.APP_FONT_SemiBold(fontsize: self.font.pointSize)
        
    }
    
}

//class BaseLabelBold: BaseLabel {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.font = UIFont.APP_FONT_Bold(fontsize: 14.0)
//    }
//
//}







//class BaseCountdownLabelBold: MZTimerLabel,MZTimerLabelDelegate {
//
//    var timerFinishHandler: timerLableFinishBlock = nil
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//
//        self.font = UIFont.APP_FONT_Bold(fontsize: 14.0)
//        self.timerType = MZTimerLabelTypeTimer
//        self.delegate = self
//    }
//
//    func setTimerSecond(seconds : TimeInterval){
//        self.setCountDownTime(seconds)
//        self.start()
//    }
//
//    func stopTimer() {
//        self.pause()
//    }
//
//    //MARK:- Timer Delegate
//    func timerLabel(_ timerLabel: MZTimerLabel!, customTextToDisplayAtTime time: TimeInterval) -> String! {
//
//        if !time.isNaN{
//
//
//            let day = Int(time / 86400)
//            let hour = Int((time.truncatingRemainder(dividingBy: 86400) / 3600))
//            let minute = Int((time.truncatingRemainder(dividingBy: 3600) / 60))
//            let second = Int((time.truncatingRemainder(dividingBy: 3600).truncatingRemainder(dividingBy: 60)))
//
//            if day == 0 {
//                if hour == 0 {
//                    if minute == 0 {
//                        return String(format: "%02ds",second)
////                        return String(format: "%02dsec",second)
//                    }else{
//                        return String(format: "%02dm : %02ds",minute,second)
////                        return String(format: "%02dmin : %02dsec",minute,second)
//                    }
//                }else{
//                    return String(format: "%02dh : %02dm : %02ds",hour,minute,second)
////                    return String(format: "%02dh : %02dmin : %02dsec",hour,minute,second)
//                }
//            }else{
//                return String(format: "%02dd : %02dh : %02dm : %02ds", day,hour,minute,second)
////                return String(format: "%02dd : %02dh : %02dmin : %02dsec", day,hour,minute,second)
//            }
//        }
//        return ""
//    }
//
//    func timerLabel(_ timerLabel: MZTimerLabel!, finshedCountDownTimerWithTime countTime: TimeInterval) {
//        if let validHandler = self.timerFinishHandler {
//            validHandler(true)
//        }
//    }
//
//}



//class BaseMarqueeLabel: MarqueeLabel {
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        self.type = .continuous
//        self.animationCurve = .linear
//    }
//
//
//    override public var canBecomeFirstResponder: Bool {
//        get {
//            return true
//        }
//    }
//
//    func longPressMenu() {
//        isUserInteractionEnabled = true
//        addGestureRecognizer(UILongPressGestureRecognizer(
//            target: self,
//            action: #selector(showMenu(sender:))
//        ))
//    }
//
//    //    func canBecomeFirstResponder() -> Bool {
//    //        return true
//    //    }
//
//    override func copy(_ sender: Any?) {
//        UIPasteboard.general.string = text
//        UIMenuController.shared.setMenuVisible(false, animated: true)
//    }
//
//    @objc func showMenu(sender: Any?) {
//        becomeFirstResponder()
//        let menu = UIMenuController.shared
//        if !menu.isMenuVisible {
//            menu.setTargetRect(bounds, in: self)
//            menu.setMenuVisible(true, animated: true)
//        }
//    }
//
//
//
//    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
//        return (action == #selector(copy(_:)))
//    }
//
//
//}

//class BaseMarqueeLabelLight: BaseMarqueeLabel {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.font = UIFont.APP_FONT_Light(fontsize: 14.0)
//    }
//
//
//
//}
//
//class BaseMarqueeLabelRegular: BaseMarqueeLabel {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.font = UIFont.APP_FONT_Regular(fontsize: 14.0)
//    }
//
//}
//
//class BaseMarqueeLabelSemiBold: BaseMarqueeLabel {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.font = UIFont.APP_FONT_SemiBold(fontsize: 14.0)
//
//    }
//
//}
//
//class BaseMarqueeLabelBold: BaseMarqueeLabel {
//
//    override func awakeFromNib()
//    {
//        super.awakeFromNib()
//        self.font = UIFont.APP_FONT_Bold(fontsize: 14.0)
//    }
//
//}
//
