//
//  ThemeProtocol.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit


protocol ThemeProtocol {
    
    var clearColor: UIColor { get }
    var whiteColor: UIColor { get }
    var devideColor: UIColor { get }
    var blackColor: UIColor { get }
    var imageBorder: UIColor { get }
    
    //App Extra Color Backgroud Color
    var appRedGoogle: UIColor { get }
    var appBlueFacebook: UIColor { get }
    var appRed: UIColor { get }
    var appOrange: UIColor { get }
    var appGreen: UIColor { get }
    
    //Rating Star Backgroud Color
    var ratingColor: UIColor { get }
    
    //view Theme Backgroud Color (Only for theme color change)
    var viewThemeDarkBackgroundColor: UIColor { get }
    var viewThemeMediumBackgroundColor: UIColor { get }
    var viewThemeLightBackgroundColor: UIColor { get }
    
    //view Default Backgroud Color
    var viewDarkBackgroundColor: UIColor { get }
    var viewMediumBackgroundColor: UIColor { get }
    var viewLightBackgroundColor: UIColor { get }
    
    //Button Backgroud Color
    var buttonDarkBackgroundColor: UIColor { get }
    var buttonMediumBackgroundColor: UIColor { get }
    var buttonLightBackgroundColor: UIColor { get }
    var buttonMoreLightBackgroundColor: UIColor { get }
    
    //Button Backgroud Color
    var buttonThemeDarkBackgroundColor: UIColor { get }
    var buttonThemeMediumBackgroundColor: UIColor { get }
    var buttonThemeLightBackgroundColor: UIColor { get }
    var buttonThemeMoreLightBackgroundColor: UIColor { get }
    
    //Text Theme Color (Only for theme color change)
    var textThemeDarkColor: UIColor { get }
    var textThemeMediumColor: UIColor { get }
    var textThemeLightColor: UIColor { get }
    
    //Text Default Color
    var textDarkColor: UIColor { get }
    var textMediumColor: UIColor { get }
    var textLightColor: UIColor { get }
    
    //Text Status Color
    var textRedColor: UIColor { get }
    var textGreenColor: UIColor { get }
    var textOrangeColor: UIColor { get }
    
    //Shadow Theme Color (Only for theme color change)
    var shadowThemeDarkColor: UIColor { get }
    var shadowThemeMediumColor: UIColor { get }
    var shadowThemeLightColor: UIColor { get }
    
    //Shadow Default Color
    var shadowDarkColor: UIColor { get }
    var shadowMediumColor: UIColor { get }
    var shadowLightColor: UIColor { get }
    
    //Border Theme Color (Only for theme color change)
    var borderThemeDarkColor: UIColor { get }
    var borderThemeMediumColor: UIColor { get }
    var borderThemeLightColor: UIColor { get }
    
    //Border Default Color
    var borderDarkColor: UIColor { get }
    var borderMediumColor: UIColor { get }
    var borderLightColor: UIColor { get }
    
}

protocol FontProtocol {
    
    
    
    var Regular: String { get }
    
    var Semibold: String { get }
    
    
    
    
}

