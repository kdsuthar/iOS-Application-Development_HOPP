//
//  WalkViewController.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import UIKit
enum WalkthroughType: Int{
    case
    walk1,
    walk2,
    walk3
    
    var title: String {
        switch self {
        case .walk1:
            
            return "WELCOME TO HOPP!"
            
        case .walk2:
            
            return "HOW IT WORKS"
            
        case .walk3:
            
            return "SAVE MONEY"
            
        }
    }
    // var topPos: CGFloat {
    //     switch self {
    //    case .walk1:
    
    //       return GET_PROPORTIONAL_HEIGHT(height: 117.31)
    //  case .walk2:
    
    //     return GET_PROPORTIONAL_HEIGHT(height: 69.27)
    
    //    case .walk3:
    
    //       return GET_PROPORTIONAL_HEIGHT(height: 77)
    
    //  }
    //  }
    // var leadingPos: CGFloat {
    //   switch self {
    //   case .walk1:
    
    //     return GET_PROPORTIONAL_WIDTH(width: 72.05)
    
    //  case .walk2:
    
    //      return GET_PROPORTIONAL_WIDTH(width: 81)
    //  case .walk3:
    
    //      return GET_PROPORTIONAL_WIDTH(width: 59.06)
    //  }
    // }
    //  var trailingPos: CGFloat {
    //     switch self {
    //    case .walk1:
    
    //       return GET_PROPORTIONAL_WIDTH(width: 54.1)
    
    //   case .walk2:
    
    //      return GET_PROPORTIONAL_WIDTH(width: 80.6)
    //   case .walk3:
    
    //    return GET_PROPORTIONAL_WIDTH(width: 49.43)
    //  }
    // }
    
    var subTitle:String{
        switch self {
        case .walk1:
            return "Hopp is the revolutionary co-riding app that is changing how people go places. Find a road buddy to share a car with while saving money and reducing your carbon footprint."
            
        case .walk2:
            return "Whether you’re looking for passengers or a driver, just tell us where you’re heading and when, create your profile, and we will match you with road buddies based on similar interests."
        case .walk3:
            return "Passengers contribute gas money. Drivers drive. Gas money is automatically transferred from the passenger’s to driver’s bank account. Easy peasy."
        }
    }
    
    //  var image:UIImage{
    //     switch self {
    //     case .walk1:
    //       return R.image.walkthrough_1()!
    //  case .walk2:
    //   return R.image.walkthrough_2()!
    //case .walk3:
    //     return R.image.walkthrough_3()!
    // }
    //}
}

class WalkViewController: UIViewController {

    
    @IBOutlet weak var labelTtitle: BaseLabelSemiBold!
    
    @IBOutlet weak var buttonNext: BaseButtonSemiBold!
        {
        didSet {
            
            buttonNext.setTitleWithText("Next")
           // buttonNext.setUpThemeButton()
        }
    }
    @IBOutlet weak var labelSubTitle: BaseLabelRegular!
    
    @IBOutlet weak var pageControl: UIPageControl!
    var currentPage = 0
    var currentWalk : WalkthroughType = .walk1
    @IBOutlet weak var buttonSkip: BaseButtonSemiBold!
        {
        didSet
        {
            //buttonSkip.setUpClearButton()
            buttonSkip.isHidden = true
        }
    }
    
    @IBOutlet weak var walkThroughCollectionView: WalkthroughCollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func click_buttonNext(_ sender: UIButton) {
        if self.currentPage == 2
        {
            isWalkThrough = true
        }
        else
        {
            
            self.currentPage = self.currentPage + 1
            
            if self.currentPage == 0 {
               // self.setUpData(walk: .walk1)
            }else if self.currentPage == 1  {
                //self.setUpData(walk: .walk2)
            }else if self.currentPage == 2  {
                //self.setUpData(walk: .walk3)
            }
        }
        
    }
    

    @IBAction func click_buttonSkip(_ sender: UIButton) {
    }
    
}
extension WalkViewController
{
    func setUpUI(){
        
        self.navigationItem.title = ""
        self.walkThroughCollectionView.arrEventType = [.walk1,.walk2,.walk3]
        self.pageControl.numberOfPages = 3
      
    }
    
    func setUpData(walk : WalkthroughType){
        
        if walk == .walk1 {
            self.walkThroughCollectionView.scrollToItem(at: IndexPath(row: 0, section: 0), at: .centeredHorizontally, animated: true)
              //self.pageControl.progress = Double(CGFloat(0))
        if self.currentWalk == .walk2
        {
            UIView.transition(with: self.labelTtitle, duration: 1.0, options: .transitionFlipFromLeft, animations: {self.labelTtitle.text = walk.title}, completion: nil)
            UIView.transition(with: self.labelSubTitle , duration: 1.0, options: .transitionFlipFromLeft, animations: {
                
                self.labelSubTitle.text = walk.subTitle
            }, completion: nil)
            UIView.transition(with: self.buttonNext , duration: 1.0, options: .transitionFlipFromLeft, animations: {
                
                self.setButtonTitle(strTitle: "NEXT")
            }, completion: nil)
            }
            else
        {
            //self.setButtonTitle(strTitle: "NEXT")
           // self.imageVIew.image = walk.image
            self.labelTtitle.text = walk.title
            self.labelSubTitle.text = walk.subTitle
            
            }
        }
        else if walk == .walk2 {
            
            self.walkThroughCollectionView.scrollToItem(at: IndexPath(row: 1, section: 0), at: .centeredHorizontally, animated: true)
        // self.pageControl.progress = Double(CGFloat(1))
            //      self.imageVIew.image = walk.image
                          self.labelTtitle.text = walk.title
                     self.labelSubTitle.text = walk.subTitle
            
            
            if self.currentWalk == .walk1 {
            
                UIView.transition(with: self.labelTtitle , duration: 1.0, options: .transitionFlipFromRight, animations: {
                    
                    self.labelTtitle.text = walk.title
                    
                }, completion: nil)
                UIView.transition(with: self.labelSubTitle , duration: 1.0, options: .transitionFlipFromRight, animations: {
                    
                    self.labelSubTitle.text = walk.subTitle
                }, completion: nil)
                UIView.transition(with: self.buttonNext , duration: 1.0, options: .transitionFlipFromRight, animations: {
                    
                self.setButtonTitle(strTitle: "NEXT")
                }, completion: nil)
                
            }
            else if self.currentWalk == .walk3 {
    
                UIView.transition(with: self.labelTtitle , duration: 1.0, options: .transitionFlipFromLeft, animations: {
                    
                    self.labelTtitle.text = walk.title
                    
                }, completion: nil)
                UIView.transition(with: self.labelSubTitle , duration: 1.0, options: .transitionFlipFromLeft, animations: {
                    
                    self.labelSubTitle.text = walk.subTitle
                }, completion: nil)
                UIView.transition(with: self.buttonNext, duration: 1.0, options: .transitionFlipFromLeft, animations: {
                    
                   self.setButtonTitle(strTitle: "NEXT")
                }, completion: nil)
            }
        }else if walk == .walk3 {
            
            self.walkThroughCollectionView.scrollToItem(at: IndexPath(row: 2, section: 0), at: .centeredHorizontally, animated: true)
           // self.pageControl.progress = Double(CGFloat(2))
            //            self.imageVIew.image = walk.image
                self.labelTtitle.text = walk.title
                self.labelSubTitle.text = walk.subTitle
            
           
            UIView.transition(with: self.labelTtitle , duration: 1.0, options: .transitionFlipFromRight, animations: {
                
                self.labelTtitle.text = walk.title
                
            }, completion: nil)
            UIView.transition(with: self.labelSubTitle , duration: 1.0, options: .transitionFlipFromRight, animations: {
                
                self.labelSubTitle.text = walk.subTitle
            }, completion: nil)
            UIView.transition(with: self.buttonNext , duration: 1.0, options: .transitionFlipFromRight, animations: {
                
                //                self.labelSubTitle.text = walk.subTitle
              self.setButtonTitle(strTitle: "Log In")
            }, completion: nil)
            
        }
        
        self.currentWalk = walk
        
    }
    func setButtonTitle(strTitle : String){
        self.buttonNext.setTitle(strTitle, for: .normal)
        self.buttonNext.setTitle(strTitle, for: .highlighted)
        self.buttonNext.setTitle(strTitle, for: .selected)
    }
    
    func registerBlockTextFiedl(){
        self.walkThroughCollectionView.pageControllCurrentPage = { (page) in
          //  self.pageControl.progress = Double(CGFloat(page))
            self.currentPage = page
            
            if self.currentPage == 0 {
                self.setUpData(walk: .walk1)
            }else if self.currentPage == 1  {
                self.setUpData(walk: .walk2)
            }else if self.currentPage == 2  {
                self.setUpData(walk: .walk3)
            }
            
            //            self.imageType.image = self.walkthroughCollectionView.arrEventType[page].image
        }
        
        //self.walkThroughCollectionView.scrollHandler = { (scrollView) in
        //    let page = scrollView.contentOffset.x / scrollView.bounds.width
        //    let progressInPage = scrollView.contentOffset.x - (page * scrollView.bounds.width)
      //      let progress = CGFloat(page) + progressInPage
            // self.pageControl.progress = Double(progress)
    //    }
    }
    
    
}

