//
//  viewCertificationCollectionView.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit

class WalkthroughCollectionView: BaseCollectionView
{
    var arrEventType : [WalkthroughType] = [.walk1,.walk2,.walk3] {
        didSet{
            self.reloadData()
        }
    }
    
    var currentPage = 0
    var pageControllCurrentPage:((_ index: Int) -> Void)?
    var scrollHandler:((_ scrollView: UIScrollView) -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        self.register(UINib(nibName: "WalkThroughCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "WalkThroughCollectionViewCell")
        
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.dataSource = self
        self.delegate = self
        self.allowsMultipleSelection = false
        
        
    }
    
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        currentPage = Int(scrollView.contentOffset.x) / Int(scrollView.frame.width)
        if self.pageControllCurrentPage != nil {
            self.pageControllCurrentPage!(currentPage)
        }
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.scrollHandler != nil {
            self.scrollHandler!(scrollView)
        }
    }
    
}



extension WalkthroughCollectionView : UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       // if self.cellSelectionHandler != nil {
        //    self.cellSelectionHandler!(collectionView, indexPath )
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
   // func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        
      //  return CGSize(width: collectionView.width, height: collectionView.height)
        
        //return CGSize(width: getProportionalWidth(92), height: getProportionalWidth(92))
   // }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
     //   if indexPath.section == 1 && !self.isloadMorePending {
       //     self.isloadMorePending = true
        //    if let validloadMoreBlock =  self.loadMoreHandler {
         //       validloadMoreBlock(self)
            }



extension WalkthroughCollectionView : UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1 //self.isloadMore ? 2 : 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        
        return arrEventType.count
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //        if indexPath.section == 1 {
        //            return self.retriveLoadmoreCell()
        //        }
        
        let cell : WalkThroughCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "WalkThroughCollectionViewCell", for: indexPath) as! WalkThroughCollectionViewCell
      //  cell.setUpImages(objData: self.arrEventType[indexPath.row])
        return cell
        
    }
    
    
    
    
}

