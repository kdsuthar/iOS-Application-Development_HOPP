//
//  Globals.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit


var isWalkThrough: Bool {
    get{
        return (getUserDefaultsValue("isWalkThrough") is Bool) ? getUserDefaultsValue("isWalkThrough") as! Bool : false
    }
    set{
        setUserDefaultsValue(newValue as AnyObject, "isWalkThrough")
    }
}
