//
//  UIFontExtension.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit


extension UIFont {
    
    
    //MARK:- logAllFont
    class func logAllfont() {
        for family in UIFont.familyNames as [String]
        {
            print("\(family)")
            for name in UIFont.fontNames(forFamilyName: family)
            {
                print("   \(name)")
            }
        }
    }
    
  // class func APP_FONT_Regular(fontsize size: CGFloat) -> UIFont {
  //     return UIFont(name: Theme.currentFont.Regular, size: getPropostionalFontSize(size))!
//}
    
    
  //  class func APP_FONT_SemiBold(fontsize size: CGFloat) -> UIFont {
       // return UIFont(name: Theme.currentFont.Semibold, size: getPropostionalFontSize(size))!
  //  }
    
    
    
}
