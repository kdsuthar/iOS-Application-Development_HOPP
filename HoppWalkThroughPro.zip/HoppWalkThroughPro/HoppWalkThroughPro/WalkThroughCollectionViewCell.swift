//
//  WalkThroughCollectionViewCell.swift
//  HoppWalkThrough
//
//  Created by Dhwani Shukla on 30/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import UIKit

class WalkThroughCollectionViewCell: BaseCollectionViewCell {

    @IBOutlet weak var labelTitle: BaseLabelRegular!
    
  
    @IBOutlet weak var labelSubTitle: BaseLabelRegular!
    
    @IBOutlet var viewContent: UIView!
    
    @IBOutlet var viewRound: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

   
}
