//
//  UIColorExtension.swift
//  HoppWalkThroughPro
//
//  Created by Dhwani Shukla on 31/10/19.
//  Copyright © 2019 Dhwani Shukla. All rights reserved.
//

import Foundation
import UIKit

//MARK:- Enums
enum GradientStyle {
    case leftToRight, rightToLeft, topToBottom, bottomToTop, topleftToBottomRight, topRightToBottomleft
}
extension UIColor {
    
    //MARK:- ColorwithHexString
    static func color(hex hexString:String) -> UIColor {
        let r, g, b: CGFloat
        if hexString.hasPrefix("#") {
            let start = hexString.index(hexString.startIndex, offsetBy: 1)
            let hexColor = hexString.substring(from: start)
            
            if hexColor.count == 6 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0
                
                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    g = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    b = CGFloat(hexNumber & 0x000000ff) / 255
                    
                    return UIColor.init(red: r, green: g, blue: b, alpha: 1.0)
                }
            }
        }
        return UIColor.init(red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0)
    }
    
    //MARK:- ColorwithRGB
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    //MARK:- Gradian Color
    class func createGradient(gradientStyle: GradientStyle, colors: [UIColor], frame: CGRect) -> UIColor{
        let gradient = CAGradientLayer()
        gradient.frame = frame
        var cgcolor = Array<CGColor>()
        for colorT in colors {
            cgcolor.append(colorT.cgColor)
        }
        gradient.colors = cgcolor
        switch gradientStyle {
        case .leftToRight:
            gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
            gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
        case .rightToLeft:
            gradient.startPoint = CGPoint(x: 1.0, y: 0.5)
            gradient.endPoint = CGPoint(x: 0.0, y: 0.5)
        case .topToBottom:
            gradient.startPoint = CGPoint(x: 0.5, y: 0.0)
            gradient.endPoint = CGPoint(x: 0.5, y: 1.0)
        case .bottomToTop:
            gradient.startPoint = CGPoint(x: 0.5, y: 1.0)
            gradient.endPoint = CGPoint(x: 0.5, y: 0.0)
        default:
            break
        }
        UIGraphicsBeginImageContextWithOptions(gradient.frame.size, false, 0)
        gradient.render(in: UIGraphicsGetCurrentContext()!)
        let outputImage: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return UIColor(patternImage: outputImage!)
    }
    
    
    class var appThemeColorDark: UIColor {
        get {
            return UIColor.color(hex: "#1581B7")
        }
    }
    class var appThemeColorMedium: UIColor {
        get {
            return UIColor.color(hex: "#DDF1FB")
        }
    }
    class var appThemeColorLight: UIColor {
        get {
            return UIColor.color(hex: "#F3FBFF")
        }
    }
    
    class var appThemeColorMoreLight: UIColor {
        get {
            return UIColor.color(hex: "#F3FBFF")
        }
    }
    
    
    class var appThemeShadowColorDark: UIColor {
        get {
            return UIColor.color(hex: "#1581B7") // 25%
        }
    }
    
    class var appDarkGrayColor: UIColor {
        get {
            return UIColor.color(hex: "#262626")
            
        }
    }
    
    class var appMediumGrayColor: UIColor {
        get {
            return UIColor.color(hex: "#888888")
            
        }
    }
    
    class var appLightGrayColor: UIColor {
        get {
            return UIColor.color(hex: "#E9E9E9")
        }
    }
    
    
    class var appYello: UIColor {
        get {
            return UIColor.color(hex: "#E9C71D")
        }
    }
    
    class var appGreen: UIColor {
        get {
            return UIColor.color(hex: "#06A234")
        }
    }
    
    class var appOrange: UIColor {
        get {
            return UIColor.color(hex: "#E88D16")
        }
    }
    
    class var appRed: UIColor {
        get {
            return UIColor.color(hex: "#DD4B39")
        }
    }
    
    class var appRedGoogle: UIColor {
        get {
            return UIColor.color(hex: "#DD4B39")
        }
    }
    
    
    class var appBlueFacebook: UIColor {
        get {
            return UIColor.color(hex: "#3B5999")
        }
    }
    
    
    class var appWhite: UIColor {
        get {
            return UIColor.color(hex: "#FFFFFF")
        }
    }
    
    class var appBlack: UIColor {
        get {
            return UIColor.color(hex: "#000000")
        }
    }
    
    class var appDevideBlack: UIColor {
        get {
            return UIColor.color(hex: "#DFDFDF")
        }
    }
    
    class var appImageBorderBlack: UIColor {
        get {
            return UIColor.color(hex: "#E9E9E9")
        }
    }
    
    
    
    class func createGradientColor(gradientStyle: GradientStyle, colors: [UIColor], frame: CGRect) -> UIColor{
        let gradient = CAGradientLayer()
        gradient.frame = frame
        var cgcolor = Array<CGColor>()
        for colorT in colors {
            cgcolor.append(colorT.cgColor)
        }
        gradient.colors = cgcolor
        switch gradientStyle {
        case .leftToRight:
            gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
            gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        case .rightToLeft:
            gradient.startPoint = CGPoint(x: 1.0, y: 0.5)
            gradient.endPoint = CGPoint(x: 0.0, y: 0.5)
        case .topToBottom:
            gradient.startPoint = CGPoint(x: 0.5, y: 0.0)
            gradient.endPoint = CGPoint(x: 0.5, y: 1.0)
        case .bottomToTop:
            gradient.startPoint = CGPoint(x: 0.5, y: 1.0)
            gradient.endPoint = CGPoint(x: 0.5, y: 0.0)
        default:
            break
        }
        UIGraphicsBeginImageContextWithOptions(gradient.frame.size, false, 0)
        gradient.render(in: UIGraphicsGetCurrentContext()!)
        let outputImage: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return UIColor(patternImage: outputImage!)
        //return outputImage!
    }
    
    
    
}
